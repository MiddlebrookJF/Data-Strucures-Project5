// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
namespace SnipInsight.Telemetry
{
    public static class PropertyValue
    {
        public const string NoResponse = "NoResponse";
    }
}
