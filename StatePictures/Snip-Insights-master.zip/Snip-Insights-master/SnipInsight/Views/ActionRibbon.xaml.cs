// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
using System.Windows.Controls;

namespace SnipInsight.Views
{
    /// <summary>
    /// Interaction logic for ActionRibbon.xaml
    /// </summary>
    public partial class ActionRibbon : UserControl
    {
        public ActionRibbon()
        {
            InitializeComponent();
        }
    }
}
