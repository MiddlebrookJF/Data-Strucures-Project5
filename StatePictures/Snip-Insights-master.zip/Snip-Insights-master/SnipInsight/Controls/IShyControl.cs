// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace SnipInsight.Controls
{
    public interface IShyControl
    {
        bool IsShy { get; set; }
    }
}
