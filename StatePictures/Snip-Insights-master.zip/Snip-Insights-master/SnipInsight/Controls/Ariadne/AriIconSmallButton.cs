// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
namespace SnipInsight.Controls.Ariadne
{
    class AriIconSmallButton : AriButtonBase
    {

    }
}
